import 'package:flutter/material.dart';

class SupplierReportPage extends StatelessWidget {
  final List<String> suppliers = [
    "Paim Fera",
    "Eduarda Faria",
    "João Marcos Moreira",
    "Alessandra Campos",
    "Roni Geraldo",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Relatório de Fornecedores Cadastrados"),
        centerTitle: true,
        backgroundColor: Colors.brown[700],
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Fornecedores Cadastrados",
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Colors.brown[800],
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: suppliers.length,
                itemBuilder: (context, index) {
                  // Pegando a inicial do fornecedor
                  String initial = suppliers[index].split(" ")[0][0];

                  return Card(
                    elevation: 4,
                    margin: EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.orange[600],
                        child: Text(
                          initial,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(
                        suppliers[index],
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.brown[800],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
