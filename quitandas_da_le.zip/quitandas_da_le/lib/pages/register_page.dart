import 'package:flutter/material.dart';
import '../service/local_storage_service.dart';
import 'token_screen.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final LocalStorageService _localStorageService = LocalStorageService();

  // Função de registro simulada
  Future<void> _register() async {
    String name = _nameController.text;
    String email = _emailController.text;
    String password = _passwordController.text;

    // Simulação de registro - substitua por uma chamada de API real
    if (name.isNotEmpty && email.isNotEmpty && password.isNotEmpty) {
      // Suponha que o servidor retorna um token após o registro
      String token = "token_de_exemplo_registro";

      // Salvando o token no SharedPreferences
      await _localStorageService.saveToken(token);

      // Redirecionando para a tela principal após o registro
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => TokenScreen()),
      );
    } else {
      // Exibe uma mensagem de erro se os campos estiverem vazios
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Preencha todos os campos")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Registro de usuário"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "E-mail"),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: "Senha"),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _register,
              child: Text("Registrar"),
            ),
          ],
        ),
      ),
    );
  }
}
