import 'package:flutter/material.dart';
import 'service/local_storage_service.dart';
import 'pages/login_page.dart';
import 'pages/home_screen.dart'; // Importando HomeScreen

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FutureBuilder(
        future: _checkLoginStatus(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasData && snapshot.data == true) {
            return HomeScreen(); // Usuário logado vai para a tela com menu
          } else {
            return LoginPage(); // Usuário não logado vai para a página de login
          }
        },
      ),
    );
  }

  // Função para verificar se o usuário está logado
  Future<bool> _checkLoginStatus() async {
    final localStorageService = LocalStorageService();
    String? token = await localStorageService.getToken();
    return token != null;
  }
}
