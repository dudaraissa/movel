package com.example.quitandas_da_le

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
